require('./lib/img.css');
