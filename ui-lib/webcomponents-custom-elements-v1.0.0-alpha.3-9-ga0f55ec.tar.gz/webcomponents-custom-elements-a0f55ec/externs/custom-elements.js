var CustomElementRegistry;
CustomElementRegistry.prototype.enableFlush = false;
CustomElementRegistry.prototype.forcePolyfill = false;
