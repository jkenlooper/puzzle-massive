MutationObserver.prototype.takeRecords = function() {};
