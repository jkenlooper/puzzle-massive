0.0.1 / Feb 1, 2012
==================

  * Added package.json and published to npm <http://search.npmjs.org/#/minpubsub>.

0.0.1 / April 21, 2011
==================

  * Initial release