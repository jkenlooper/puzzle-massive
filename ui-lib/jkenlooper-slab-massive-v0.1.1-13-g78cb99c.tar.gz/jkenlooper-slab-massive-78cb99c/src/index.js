import './slab-massive.js'
